# clothingRecommendation

 A simple clothing recommendation system based on purchased clothing, made with PHP.

<h6 align="center">purchase page preview</h6>
<h6 align="center"><kbd><img src="https://github.com/rangel-pci/files/blob/master/simple_recommendation_system.png" /><kbd/></h6>
